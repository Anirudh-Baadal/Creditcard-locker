# Creditcard-locker

![image](https://user-images.githubusercontent.com/79414752/131528438-268a0e06-6c15-4937-a346-5254b6845dd9.png)


This is temporary storage unit to store your credit/debit card number, mobile number and CVV.

Here dictionary is used to store the details where inputs from the user is taken as list and that list is saved as 'key' for the dictionary and then the username is taken as 'value' for our dictionary.

unique feature is that we use 'value' to print 'key' rather than using 'key' to print 'value'.

 
 
